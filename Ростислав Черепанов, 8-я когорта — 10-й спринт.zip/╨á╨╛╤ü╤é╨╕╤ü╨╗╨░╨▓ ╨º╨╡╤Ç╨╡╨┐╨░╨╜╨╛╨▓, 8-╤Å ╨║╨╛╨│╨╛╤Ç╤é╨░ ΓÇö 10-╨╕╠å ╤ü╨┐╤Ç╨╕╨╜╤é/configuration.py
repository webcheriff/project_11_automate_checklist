URL_SERVICE = "https://e835dc67-da3b-4f0d-80d2-714d647c3397.serverhub.praktikum-services.ru"
CREATE_PRODUCTS_KIT_PATH = "/api/v1/kits"
CREATE_USER_PATH = "/api/v1/users/"
