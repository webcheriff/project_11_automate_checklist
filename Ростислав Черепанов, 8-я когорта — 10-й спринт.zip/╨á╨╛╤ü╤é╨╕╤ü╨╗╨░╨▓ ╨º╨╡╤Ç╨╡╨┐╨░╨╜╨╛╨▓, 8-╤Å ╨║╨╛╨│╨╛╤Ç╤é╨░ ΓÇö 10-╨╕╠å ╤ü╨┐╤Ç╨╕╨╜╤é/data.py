headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer "
}

user_body = {
    "firstName": "Анатолий",
    "phone": "+79995553322",
    "address": "г. Москва, ул. Пушкина, д. 10"
}

kit_body = {
       "name": "Мой набор"
   }
